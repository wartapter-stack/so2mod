package com.so2.mod;

import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.*;
import java.net.*;
import java.nio.*;
import java.nio.channels.*;
import java.util.*;

/**
 * Локальный VPN — перехватывает UDP пакеты Standoff 2.
 * SO2 использует UDP на портах 7700-7800 (game server) и 3478/3479 (relay).
 *
 * Архитектура:
 *   TUN interface → читаем IP/UDP пакеты → парсим game state → обновляем EntityStore
 *   → форвардим оригинальный пакет дальше без изменений (stealth)
 *
 * Для аимбота: инжектируем модифицированный input пакет с нужным углом.
 */
public class ProxyVpnService extends VpnService {

    static final String TAG = "SO2Proxy";

    // SO2 game server ports (обновить если изменились)
    static final int[] GAME_PORTS = {7700, 7701, 7702, 7703, 7704, 7705};

    ParcelFileDescriptor vpnInterface;
    volatile boolean running = false;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        running = true;
        new Thread(this::runVpn).start();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        try { if (vpnInterface != null) vpnInterface.close(); } catch (Exception ignored) {}
        EntityStore.clear();
    }

    void runVpn() {
        try {
            Builder b = new Builder();
            b.setSession("SO2Mod");
            b.addAddress("10.0.0.2", 32);
            b.addRoute("0.0.0.0", 0);
            b.addDnsServer("8.8.8.8");
            b.setMtu(1500);
            vpnInterface = b.establish();

            FileInputStream  in  = new FileInputStream(vpnInterface.getFileDescriptor());
            FileOutputStream out = new FileOutputStream(vpnInterface.getFileDescriptor());

            byte[] packet = new byte[65535];

            while (running) {
                int len = in.read(packet);
                if (len <= 0) continue;

                byte[] pkt = Arrays.copyOf(packet, len);

                // парсим IP заголовок
                if (len < 20) { out.write(pkt); continue; }

                int ipVersion = (pkt[0] >> 4) & 0xF;
                if (ipVersion != 4) { out.write(pkt); continue; }

                int protocol = pkt[9] & 0xFF; // 17 = UDP
                if (protocol != 17) { out.write(pkt); continue; }

                int ipHeaderLen = (pkt[0] & 0xF) * 4;
                if (len < ipHeaderLen + 8) { out.write(pkt); continue; }

                int srcPort  = ((pkt[ipHeaderLen]   & 0xFF) << 8) | (pkt[ipHeaderLen+1] & 0xFF);
                int dstPort  = ((pkt[ipHeaderLen+2] & 0xFF) << 8) | (pkt[ipHeaderLen+3] & 0xFF);

                boolean isGame = isGamePort(srcPort) || isGamePort(dstPort);

                if (isGame) {
                    int udpPayloadOffset = ipHeaderLen + 8;
                    int udpPayloadLen    = len - udpPayloadOffset;
                    if (udpPayloadLen > 0) {
                        byte[] payload = Arrays.copyOfRange(pkt, udpPayloadOffset, len);
                        processGamePacket(payload, dstPort);
                    }
                }

                // всегда форвардим оригинал — пакет не изменяем (stealth)
                out.write(pkt, 0, len);
            }

        } catch (Exception e) {
            Log.e(TAG, "VPN error", e);
        }
    }

    boolean isGamePort(int port) {
        for (int p : GAME_PORTS) if (p == port) return true;
        return false;
    }

    /**
     * Парсим game state пакет SO2.
     *
     * SO2 использует кастомный бинарный протокол поверх UDP.
     * Структура пакета (приблизительная, реверс через Wireshark):
     *
     * [0]    - packet type (0x01 = world update, 0x02 = player list, ...)
     * [1-2]  - sequence number
     * [3-N]  - entity блоки
     *
     * Entity блок (~32 байта):
     * [0-1]  player_id
     * [2]    team (1=CT, 2=T)
     * [3]    hp (0-100)
     * [4-7]  world_x (float)
     * [8-11] world_y (float)
     * [12-15]world_z (float)
     * [16-19]yaw (float)
     * [20]   is_alive
     * ...
     *
     * NOTE: реальная структура зависит от версии SO2 — нужен Wireshark dump
     * для точного реверса. Ниже — скелет парсера с screen projection.
     */
    void processGamePacket(byte[] data, int dstPort) {
        if (data.length < 4) return;

        int pktType = data[0] & 0xFF;

        // world update пакет
        if (pktType == 0x01 && data.length >= 4) {
            List<EntityStore.Entity> entities = new ArrayList<>();

            int offset = 3; // пропускаем header
            int entitySize = 21; // размер одного entity блока

            while (offset + entitySize <= data.length) {
                try {
                    int  team    = data[offset + 2] & 0xFF;
                    int  hp      = data[offset + 3] & 0xFF;
                    float wx     = ByteBuffer.wrap(data, offset + 4,  4).order(ByteOrder.LITTLE_ENDIAN).getFloat();
                    float wy     = ByteBuffer.wrap(data, offset + 8,  4).order(ByteOrder.LITTLE_ENDIAN).getFloat();
                    float wz     = ByteBuffer.wrap(data, offset + 12, 4).order(ByteOrder.LITTLE_ENDIAN).getFloat();
                    boolean alive = (data[offset + 20] & 0xFF) == 1;

                    if (alive && hp > 0 && team > 0) {
                        // простая проекция world → screen (нужна view matrix от клиента)
                        // без view matrix используем упрощённую эвристику по дистанции
                        float[] screen = worldToScreen(wx, wy, wz);
                        if (screen != null) {
                            float dist = (float)Math.sqrt(wx*wx + wy*wy);
                            float boxH = Math.max(40f, 300f / (dist * 0.01f + 1f));
                            float boxW = boxH * 0.5f;
                            entities.add(new EntityStore.Entity(
                                screen[0], screen[1], boxW, boxH, hp, team
                            ));
                        }
                    }
                } catch (Exception ignored) {}

                offset += entitySize;
            }

            EntityStore.update(entities);
        }
    }

    /**
     * Проекция мировых координат на экран.
     * Без view matrix — упрощённая перспектива.
     * Для точной проекции нужна camera matrix из пакетов SO2.
     */
    float[] worldToScreen(float wx, float wy, float wz) {
        // заглушка: в реальном чите view matrix берётся из camera-update пакетов
        // здесь возвращаем null — overlay покажет entities только когда
        // парсер откалиброван под реальные пакеты
        return null;
    }
}
