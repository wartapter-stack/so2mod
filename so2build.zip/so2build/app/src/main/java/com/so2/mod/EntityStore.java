package com.so2.mod;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Общее хранилище entity — между ProxyVpnService и OverlayService.
 * ProxyVpnService пишет, OverlayService читает.
 */
public class EntityStore {

    public static class Entity {
        public float screenX, screenY; // центр низа бокса
        public float boxW, boxH;       // размер бокса
        public float hp;               // 0-100
        public float headX, headY;     // для аима
        public boolean visible;
        public int   team;             // 1=CT, 2=T

        public Entity(float sx, float sy, float bw, float bh, float hp, int team) {
            this.screenX = sx; this.screenY = sy;
            this.boxW = bw;   this.boxH = bh;
            this.hp = hp;     this.team = team;
            this.headX = sx;  this.headY = sy - bh;
            this.visible = true;
        }
    }

    private static final CopyOnWriteArrayList<Entity> entities = new CopyOnWriteArrayList<>();

    public static void update(List<Entity> newEntities) {
        entities.clear();
        entities.addAll(newEntities);
    }

    public static List<Entity> getEntities() {
        return new ArrayList<>(entities);
    }

    public static void clear() {
        entities.clear();
    }
}
