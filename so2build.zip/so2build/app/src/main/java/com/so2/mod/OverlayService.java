package com.so2.mod;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.View;
import android.view.WindowManager;
import java.util.List;

/**
 * Overlay сервис — рисует ESP боксы и аим-линии поверх игры.
 * Данные о врагах приходят от ProxyVpnService через EntityStore.
 */
public class OverlayService extends Service {

    WindowManager wm;
    ESPView       espView;

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(1, buildNotif());

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );

        espView = new ESPView(this);
        wm.addView(espView, params);

        // обновление ~60fps
        espView.postDelayed(new Runnable() {
            @Override public void run() {
                espView.invalidate();
                espView.postDelayed(this, 16);
            }
        }, 16);
    }

    @Override
    public void onDestroy() {
        if (espView != null) wm.removeView(espView);
    }

    @Override public IBinder onBind(Intent i) { return null; }

    Notification buildNotif() {
        String ch = "mod_ch";
        NotificationChannel nc = new NotificationChannel(ch, "Service", NotificationManager.IMPORTANCE_MIN);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(nc);
        return new Notification.Builder(this, ch)
            .setContentTitle("System Service")
            .setSmallIcon(android.R.drawable.ic_menu_preferences)
            .build();
    }

    // ── ESP VIEW ─────────────────────────────────────────────────────────────
    static class ESPView extends View {

        Paint boxPaint   = new Paint();
        Paint aimPaint   = new Paint();
        Paint textPaint  = new Paint();
        Paint fillPaint  = new Paint();

        // меню toggle — долгое нажатие на ватермарку
        boolean menuVisible = false;

        ESPView(android.content.Context ctx) {
            super(ctx);

            boxPaint.setColor(Color.RED);
            boxPaint.setStyle(Paint.Style.STROKE);
            boxPaint.setStrokeWidth(2.5f);
            boxPaint.setAntiAlias(true);

            aimPaint.setColor(Color.argb(180, 255, 80, 80));
            aimPaint.setStyle(Paint.Style.STROKE);
            aimPaint.setStrokeWidth(1.2f);

            textPaint.setColor(Color.WHITE);
            textPaint.setTextSize(28f);
            textPaint.setAntiAlias(true);

            fillPaint.setColor(Color.argb(40, 255, 0, 0));
            fillPaint.setStyle(Paint.Style.FILL);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            List<EntityStore.Entity> entities = EntityStore.getEntities();
            if (entities == null || entities.isEmpty()) return;

            float sw = getWidth();
            float sh = getHeight();
            float cx = sw / 2f;
            float cy = sh / 2f;

            for (EntityStore.Entity e : entities) {
                if (!e.visible) continue;

                // координаты бокса
                float bx = e.screenX;
                float by = e.screenY;
                float bw = e.boxW;
                float bh = e.boxH;

                // HP цвет
                int r = (int)((1f - e.hp / 100f) * 255);
                int g = (int)(e.hp / 100f * 255);
                boxPaint.setColor(Color.rgb(r, g, 0));

                // bounding box
                canvas.drawRect(bx - bw/2, by - bh, bx + bw/2, by, boxPaint);

                // заливка
                canvas.drawRect(bx - bw/2, by - bh, bx + bw/2, by, fillPaint);

                // hp bar слева
                float barH = bh;
                float filled = barH * (e.hp / 100f);
                Paint barBg = new Paint(); barBg.setColor(Color.argb(120,0,0,0)); barBg.setStyle(Paint.Style.FILL);
                Paint barFg = new Paint(); barFg.setColor(Color.rgb(r,g,0));      barFg.setStyle(Paint.Style.FILL);
                canvas.drawRect(bx - bw/2 - 8, by - bh, bx - bw/2 - 5, by, barBg);
                canvas.drawRect(bx - bw/2 - 8, by - filled, bx - bw/2 - 5, by, barFg);

                // hp число
                canvas.drawText(String.valueOf((int)e.hp), bx - bw/2, by - bh - 4, textPaint);

                // snap line
                aimPaint.setColor(Color.argb(120, 255, 60, 60));
                canvas.drawLine(cx, sh, bx, by, aimPaint);

                // аим-точка на голове
                Paint dot = new Paint(); dot.setColor(Color.YELLOW); dot.setStyle(Paint.Style.FILL);
                canvas.drawCircle(bx, by - bh, 5f, dot);
            }

            // ватермарка
            Paint wm = new Paint(); wm.setColor(Color.argb(80,255,255,255)); wm.setTextSize(22f);
            canvas.drawText("●", 20, sh - 20, wm);
        }
    }
}
